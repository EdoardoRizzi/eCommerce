<?php
if(isset($_SESSION['ID'])){
    header("location:Index.php");
}
?>